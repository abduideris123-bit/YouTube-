// api/auth.js — Vercel Serverless Function
// YouTube OAuth token exchange & refresh
// Environment variables needed:
//   YT_CLIENT_ID     — Google Cloud OAuth Client ID
//   YT_CLIENT_SECRET — Google Cloud OAuth Client Secret

export default async function handler(req, res) {
  // CORS — ፋይሉ ያለበት domain ፍቀድ (ወይም * development ጊዜ)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST")   return res.status(405).json({ error: "Method not allowed" });

  const { action, code, redirect_uri, refresh_token, code_verifier } = req.body || {};

  const CLIENT_ID     = process.env.YT_CLIENT_ID;
  const CLIENT_SECRET = process.env.YT_CLIENT_SECRET;

  if (!CLIENT_ID || !CLIENT_SECRET) {
    return res.status(500).json({ error: "Server config missing: YT_CLIENT_ID / YT_CLIENT_SECRET" });
  }

  // ── ACTION: exchange ──────────────────────────────────────
  // Authorization code → access_token + refresh_token
  if (action === "exchange") {
    if (!code || !redirect_uri) {
      return res.status(400).json({ error: "code and redirect_uri required" });
    }

    const body = new URLSearchParams({
      code,
      client_id:     CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uri,
      grant_type:    "authorization_code",
    });

    // PKCE code_verifier ካለ ጨምር
    if (code_verifier) body.set("code_verifier", code_verifier);

    try {
      const r = await fetch("https://oauth2.googleapis.com/token", {
        method:  "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body:    body.toString(),
      });

      const data = await r.json();

      if (!r.ok) {
        console.error("Token exchange error:", data);
        return res.status(r.status).json({ error: data.error_description || data.error || "Exchange failed" });
      }

      return res.status(200).json({
        access_token:  data.access_token,
        refresh_token: data.refresh_token,
        expires_in:    data.expires_in || 3599,
        token_type:    data.token_type,
      });
    } catch (err) {
      console.error("Exchange fetch error:", err);
      return res.status(500).json({ error: "Network error during token exchange" });
    }
  }

  // ── ACTION: refresh ───────────────────────────────────────
  // refresh_token → new access_token
  if (action === "refresh") {
    if (!refresh_token) {
      return res.status(400).json({ error: "refresh_token required" });
    }

    try {
      const r = await fetch("https://oauth2.googleapis.com/token", {
        method:  "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body:    new URLSearchParams({
          refresh_token,
          client_id:     CLIENT_ID,
          client_secret: CLIENT_SECRET,
          grant_type:    "refresh_token",
        }).toString(),
      });

      const data = await r.json();

      if (!r.ok) {
        console.error("Token refresh error:", data);
        // refresh_token ፈቃዱ ከተሰረዘ → 400/401
        return res.status(r.status).json({ error: data.error_description || data.error || "Refresh failed" });
      }

      return res.status(200).json({
        access_token:  data.access_token,
        // Google ሁሌም refresh_token refresh ላይ አይመልስም — ያለውን ጠብቅ
        refresh_token: data.refresh_token || refresh_token,
        expires_in:    data.expires_in || 3599,
      });
    } catch (err) {
      console.error("Refresh fetch error:", err);
      return res.status(500).json({ error: "Network error during token refresh" });
    }
  }

  return res.status(400).json({ error: "Unknown action. Use 'exchange' or 'refresh'." });
}
